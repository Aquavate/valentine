
import React, { useState, useCallback } from 'react';
import { Page } from './types';
import IntroPage from './components/IntroPage';
import QuizPage from './components/QuizPage';
import ProposalPage from './components/ProposalPage';
import SuccessPage from './components/SuccessPage';
import BackgroundHearts from './components/BackgroundHearts';
import BackgroundMusic from './components/BackgroundMusic';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>(Page.INTRO);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);

  const navigateTo = useCallback((page: Page) => {
    setCurrentPage(page);
  }, []);

  const startExperience = useCallback(() => {
    setIsMusicPlaying(true);
    navigateTo(Page.QUIZ);
  }, [navigateTo]);

  return (
    <div className="min-h-screen w-full relative overflow-hidden flex flex-col items-center justify-center p-4">
      <BackgroundHearts />
      <BackgroundMusic isPlaying={isMusicPlaying} setIsPlaying={setIsMusicPlaying} />
      
      <main className="w-full max-w-2xl z-10">
        {currentPage === Page.INTRO && (
          <IntroPage onContinue={startExperience} />
        )}
        
        {currentPage === Page.QUIZ && (
          <QuizPage onCorrect={() => navigateTo(Page.PROPOSAL)} />
        )}
        
        {currentPage === Page.PROPOSAL && (
          <ProposalPage 
            onYes={() => navigateTo(Page.SUCCESS)} 
          />
        )}
        
        {currentPage === Page.SUCCESS && (
          <SuccessPage />
        )}
      </main>

      <footer className="absolute bottom-4 text-pink-400 text-sm opacity-50">
        Made with ❤️ for Toa
      </footer>
    </div>
  );
};

export default App;
