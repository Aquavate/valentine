
import React, { useEffect, useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import Confetti from './Confetti';

const SuccessPage: React.FC = () => {
  const [loveNote, setLoveNote] = useState<string>("Loading your special message...");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchLoveNote = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: "Write a short, heartwarming, 3-line romantic poem for my girlfriend 'Toa' because she just said YES to being my valentine. Keep it sweet and mention her name.",
        });
        setLoveNote(response.text || "You made me the happiest person! I love you, Toa! ❤️");
      } catch (error) {
        setLoveNote("Toa, you've made me the happiest person in the world! I promise to make every day special for you. ❤️");
      } finally {
        setIsLoading(false);
      }
    };

    fetchLoveNote();
  }, []);

  return (
    <div className="text-center space-y-8 bg-white/70 backdrop-blur-lg p-12 rounded-[3rem] border-2 border-pink-300 shadow-2xl animate-in zoom-in-50 duration-1000">
      <Confetti />
      
      <div className="space-y-4">
        <h1 className="text-6xl font-romantic text-rose-600">Yay! It's a YES!</h1>
        <p className="text-2xl text-pink-500 font-medium italic">I'm so lucky to have you, Toa! ❤️</p>
      </div>

      <div className="relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-pink-400 to-rose-400 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
        <div className="relative bg-white p-8 rounded-2xl border border-pink-100 leading-relaxed text-lg text-pink-700 italic font-medium whitespace-pre-wrap">
          {isLoading ? (
            <div className="flex flex-col items-center gap-2">
              <div className="w-8 h-8 border-4 border-pink-500 border-t-transparent rounded-full animate-spin"></div>
              <p>Fetching your special note...</p>
            </div>
          ) : (
            loveNote
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <img 
          src="https://picsum.photos/seed/celebration1/300/300" 
          alt="Celebration 1" 
          className="rounded-2xl border-4 border-white shadow-lg animate-float"
        />
        <img 
          src="https://picsum.photos/seed/celebration2/301/301" 
          alt="Celebration 2" 
          className="rounded-2xl border-4 border-white shadow-lg animate-float delay-700"
        />
      </div>

      <p className="text-rose-400 font-bold text-xl animate-bounce pt-4">
        See you on Valentine's Day! 🌹
      </p>
    </div>
  );
};

export default SuccessPage;
