
import React from 'react';

interface IntroPageProps {
  onContinue: () => void;
}

const IntroPage: React.FC<IntroPageProps> = ({ onContinue }) => {
  return (
    <div className="text-center space-y-8 bg-white/40 backdrop-blur-md p-10 rounded-3xl border border-pink-200 shadow-xl animate-in fade-in zoom-in duration-700">
      <h1 className="text-4xl md:text-6xl font-romantic text-pink-600 mb-4 leading-tight">
        Hi Toa,
      </h1>
      <p className="text-2xl md:text-3xl font-medium text-pink-500 italic">
        "Your jigar ka tukra this side..."
      </p>
      
      <div className="flex justify-center py-4">
        <img 
          src="https://picsum.photos/seed/love_intro/300/300" 
          alt="Sweet Greeting" 
          className="rounded-2xl border-4 border-white shadow-lg animate-float max-w-[200px]"
        />
      </div>

      <button
        onClick={onContinue}
        className="bg-gradient-to-r from-pink-500 to-rose-400 text-white px-10 py-4 rounded-full text-xl font-bold shadow-lg hover:shadow-pink-200 hover:scale-105 transition-all duration-300"
      >
        Continue 💖
      </button>
    </div>
  );
};

export default IntroPage;
