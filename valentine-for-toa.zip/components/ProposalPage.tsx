
import React, { useState, useRef, useEffect } from 'react';

interface ProposalPageProps {
  onYes: () => void;
}

const ProposalPage: React.FC<ProposalPageProps> = ({ onYes }) => {
  const [noButtonPos, setNoButtonPos] = useState({ x: 0, y: 0 });
  const noButtonRef = useRef<HTMLButtonElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const moveButton = () => {
    if (!containerRef.current) return;
    
    const container = containerRef.current.getBoundingClientRect();
    const padding = 50;
    
    const newX = Math.random() * (container.width - 150) - (container.width / 2) + 75;
    const newY = Math.random() * (container.height - 100) - (container.height / 2) + 50;
    
    setNoButtonPos({ x: newX, y: newY });
  };

  return (
    <div 
      ref={containerRef}
      className="relative text-center space-y-10 py-16 px-4 bg-white/40 backdrop-blur-md rounded-[3rem] min-h-[400px] flex flex-col items-center justify-center border border-pink-200 overflow-visible"
    >
      <div className="space-y-4">
        <h1 className="text-5xl md:text-7xl font-romantic text-pink-600 animate-pulse">
          Will you be my Valentine?
        </h1>
        <p className="text-pink-400 text-xl italic font-medium">Please say yes! 🥺</p>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-center gap-8 w-full mt-8">
        <button
          onClick={onYes}
          className="z-10 bg-gradient-to-r from-green-400 to-emerald-500 text-white px-12 py-5 rounded-full text-2xl font-bold shadow-xl hover:scale-110 active:scale-95 transition-all duration-300"
        >
          YES! 😍
        </button>

        <button
          ref={noButtonRef}
          onMouseEnter={moveButton}
          onClick={moveButton} // For touch screens
          style={{
            transform: `translate(${noButtonPos.x}px, ${noButtonPos.y}px)`,
            transition: 'transform 0.15s cubic-bezier(0.34, 1.56, 0.64, 1)'
          }}
          className="bg-gray-200 text-gray-600 px-10 py-4 rounded-full text-xl font-bold shadow-md cursor-default pointer-events-auto"
        >
          NO 😢
        </button>
      </div>
      
      <div className="pt-10">
        <img 
          src="https://picsum.photos/seed/cute_bear/200/200" 
          alt="Please" 
          className="rounded-full border-4 border-white shadow-lg w-32 h-32 object-cover opacity-80"
        />
      </div>
    </div>
  );
};

export default ProposalPage;
