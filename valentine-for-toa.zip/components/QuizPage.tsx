
import React, { useState } from 'react';
import { QuizOption } from '../types';

interface QuizPageProps {
  onCorrect: () => void;
}

const QuizPage: React.FC<QuizPageProps> = ({ onCorrect }) => {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const options: QuizOption[] = [
    { label: "Our very first date!", isCorrect: false },
    { label: "That beautiful rainy evening...", isCorrect: true },
    { label: "Your last birthday party!", isCorrect: false },
  ];

  const handleOptionClick = (index: number) => {
    setSelectedOption(index);
    if (options[index].isCorrect) {
      setFeedback("That's right! You remember everything ❤️");
      setTimeout(() => {
        onCorrect();
      }, 1500);
    } else {
      setFeedback("Hmm, are you sure? Try again, my love! 😊");
    }
  };

  return (
    <div className="text-center space-y-6 bg-white/60 backdrop-blur-md p-8 rounded-3xl border border-pink-100 shadow-lg animate-in slide-in-from-right duration-500">
      <h2 className="text-3xl font-bold text-pink-600">Memory Lane 📸</h2>
      <p className="text-lg text-pink-500">Do you remember when this photo was taken?</p>
      
      <div className="flex justify-center">
        <img 
          src="https://picsum.photos/seed/romantic_memory/600/400" 
          alt="Memory" 
          className="rounded-xl border-4 border-white shadow-md max-h-64 object-cover"
        />
      </div>

      <div className="grid grid-cols-1 gap-3">
        {options.map((option, index) => (
          <button
            key={index}
            onClick={() => handleOptionClick(index)}
            disabled={feedback === "That's right! You remember everything ❤️"}
            className={`p-4 rounded-xl text-lg font-medium transition-all duration-300 border-2 ${
              selectedOption === index 
                ? option.isCorrect 
                  ? "bg-green-100 border-green-400 text-green-700" 
                  : "bg-red-50 border-red-300 text-red-600"
                : "bg-white border-pink-100 hover:border-pink-300 text-pink-700"
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>

      {feedback && (
        <p className={`text-lg font-semibold animate-bounce mt-4 ${
          feedback.includes("right") ? "text-green-600" : "text-rose-500"
        }`}>
          {feedback}
        </p>
      )}
    </div>
  );
};

export default QuizPage;
