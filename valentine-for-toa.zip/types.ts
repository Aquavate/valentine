
export enum Page {
  INTRO = 'INTRO',
  QUIZ = 'QUIZ',
  PROPOSAL = 'PROPOSAL',
  SUCCESS = 'SUCCESS'
}

export interface QuizOption {
  label: string;
  isCorrect: boolean;
}
